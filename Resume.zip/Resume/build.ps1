param(
  [ValidateSet('pdflatex','xelatex','lualatex')]
  [string]$Engine = 'pdflatex',
  [string]$OutDir = 'out',
  # Default to the new tailored resume
  [string]$JobName = 'crossbring_resume',
  [switch]$Open
)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $here

function Assert-Exe($name) {
  try { (Get-Command $name -ErrorAction Stop) | Out-Null; return $true } catch { return $false }
}

if (-not (Assert-Exe $Engine)) {
  Write-Warning "LaTeX engine '$Engine' not found in PATH."
  if ($Engine -eq 'pdflatex') {
    Write-Host "Hint: Install MiKTeX: winget install MiKTeX.MiKTeX" -ForegroundColor Yellow
  }
  exit 1
}

$outPath = Join-Path $here $OutDir
if (-not (Test-Path $outPath)) { New-Item -ItemType Directory -Path $outPath | Out-Null }

$sourceTex = "$JobName.tex"
if (-not (Test-Path (Join-Path $here $sourceTex))) {
  Write-Error "Source TeX '$sourceTex' not found in $here. Set -JobName to the base filename (without .tex)."
  exit 1
}
$argsCommon = @('-interaction=nonstopmode','-halt-on-error',"-jobname=$JobName",'-output-directory', $outPath, $sourceTex)

& $Engine @argsCommon
if ($LASTEXITCODE -ne 0) { Write-Error "First pass failed."; exit $LASTEXITCODE }

& $Engine @argsCommon
if ($LASTEXITCODE -ne 0) { Write-Error "Second pass failed."; exit $LASTEXITCODE }

$builtPdf = Join-Path $outPath ("$JobName.pdf")
if (-not (Test-Path $builtPdf)) { Write-Error "Build succeeded but PDF not found in output directory."; exit 1 }

$targetPdf = Join-Path $here ("$JobName.pdf")
try {
  Copy-Item -Path $builtPdf -Destination $targetPdf -Force
  Write-Host "Built: $targetPdf" -ForegroundColor Green
  if ($Open) { Start-Process $targetPdf | Out-Null }
  exit 0
} catch {
  $altPdf = Join-Path $here ("$JobName-new.pdf")
  Copy-Item -Path $builtPdf -Destination $altPdf -Force
  Write-Warning "Could not overwrite $targetPdf (is it open in a viewer?). Saved as $altPdf instead."
  if ($Open) { Start-Process $altPdf | Out-Null }
  exit 0
}
